<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * CommentVerify Action - 评论验证处理
 * 
 * 处理评论验证请求，验证token并更新评论状态
 * 
 * @package CommentVerify
 * @author AI Assistant
 * @version 1.0.0
 */

class CommentVerify_Action extends Typecho_Widget implements Widget_Interface_Do
{
    /**
     * 执行验证动作
     */
    public function action()
    {
        // 获取token参数
        $token = $this->request->get('token');
        
        // 验证token是否存在
        if (empty($token)) {
            $this->showError('缺少验证参数');
            return;
        }

        $db = Typecho_Db::get();
        
        try {
            // 计算token hash
            $tokenHash = hash_hmac('sha256', $token, CommentVerify_Plugin::SECRET_KEY);
            
            // 查找token记录
            $tokenRow = $db->fetchRow($db->select()
                ->from('table.comment_token')
                ->where('token_hash = ?', $tokenHash));
            
            if (!$tokenRow) {
                $this->showError('验证链接无效或已使用');
                return;
            }

            // 检查token是否过期
            $expireTime = CommentVerify_Plugin::TOKEN_EXPIRE;
            if (time() - $tokenRow['created'] > $expireTime) {
                $this->showError('验证链接已过期（超过' . intval($expireTime / 3600) . '小时）');
                return;
            }

            // 获取评论信息
            $comment = $db->fetchRow($db->select()
                ->from('table.comments')
                ->where('coid = ?', $tokenRow['comment_id']));
            
            if (!$comment) {
                $this->showError('评论不存在');
                return;
            }

            // 检查评论状态
            if ($comment['status'] == 'approved') {
                // 评论已通过审核，直接跳转
                $this->redirectToPost($comment['cid'], $tokenRow['comment_id']);
                return;
            }

            // 开始事务
            $db->beginTransaction();
            
            try {
                // 更新评论状态为已审核
                $db->query($db->update('table.comments')
                    ->rows(['status' => 'approved'])
                    ->where('coid = ?', $tokenRow['comment_id']));
                
                // 删除已使用的token
                $db->query($db->delete('table.comment_token')
                    ->where('comment_id = ?', $tokenRow['comment_id']));
                
                // 提交事务
                $db->commit();
                
                // 记录日志
                CommentVerify_Plugin::log("评论验证成功 CID={$tokenRow['comment_id']} / 文章ID={$comment['cid']}");
                
                // 跳转到文章页面
                $this->redirectToPost($comment['cid'], $tokenRow['comment_id']);
                
            } catch (Exception $e) {
                // 回滚事务
                $db->rollback();
                throw $e;
            }

        } catch (Exception $e) {
            // 记录错误日志
            CommentVerify_Plugin::log("验证处理错误: " . $e->getMessage() . " / Token=" . substr($token, 0, 8) . "...");
            $this->showError('验证处理失败，请稍后重试');
        }
    }

    /**
     * 跳转到文章页面
     */
    private function redirectToPost($cid, $commentId)
    {
        // 构建文章URL
        $permalink = Typecho_Common::url(
            Typecho_Router::url('archive', array('cid' => $cid), Helper::options()->index),
            Helper::options()->siteUrl
        );
        
        // 添加评论锚点
        $redirectUrl = $permalink . '#comment-' . $commentId;
        
        // 发送成功消息
        $message = CommentVerify_Plugin::lang('verify_success');
        
        // 使用JavaScript进行跳转，可以显示成功消息
        echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>' . htmlspecialchars($message) . '</title>
    <meta http-equiv="refresh" content="2;url=' . htmlspecialchars($redirectUrl) . '">
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .message {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        .success-icon {
            width: 60px;
            height: 60px;
            background: #4CAF50;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        .success-icon::after {
            content: "✓";
            color: white;
            font-size: 30px;
            font-weight: bold;
        }
        h2 {
            color: #333;
            margin: 0 0 10px 0;
        }
        p {
            color: #666;
            margin: 0;
        }
        .redirect-info {
            margin-top: 20px;
            font-size: 14px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="message">
        <div class="success-icon"></div>
        <h2>' . htmlspecialchars($message) . '</h2>
        <p>' . CommentVerify_Plugin::lang('redirecting') . '</p>
        <div class="redirect-info">
            <a href="' . htmlspecialchars($redirectUrl) . '">' . CommentVerify_Plugin::lang('click_if_not_redirect') . '</a>
        </div>
    </div>
</body>
</html>';
        
        exit();
    }

    /**
     * 显示错误页面
     */
    private function showError($message)
    {
        $errorTitle = CommentVerify_Plugin::lang('verify_failed');
        
        echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>' . htmlspecialchars($errorTitle) . '</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
        }
        .error {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            text-align: center;
            max-width: 400px;
        }
        .error-icon {
            width: 60px;
            height: 60px;
            background: #f44336;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        .error-icon::after {
            content: "✕";
            color: white;
            font-size: 30px;
            font-weight: bold;
        }
        h2 {
            color: #333;
            margin: 0 0 10px 0;
        }
        p {
            color: #666;
            margin: 0;
        }
        .back-link {
            margin-top: 20px;
        }
        .back-link a {
            color: #1a73e8;
            text-decoration: none;
        }
        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="error">
        <div class="error-icon"></div>
        <h2>' . htmlspecialchars($errorTitle) . '</h2>
        <p>' . htmlspecialchars($message) . '</p>
        <div class="back-link">
            <a href="' . Helper::options()->siteUrl . '">' . CommentVerify_Plugin::lang('back_to_home') . '</a>
        </div>
    </div>
</body>
</html>';
        
        exit();
    }
}