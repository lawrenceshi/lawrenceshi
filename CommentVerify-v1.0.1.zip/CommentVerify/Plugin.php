<?php
require_once __DIR__ . '/phpmailer/PHPMailer.php';
require_once __DIR__ . '/phpmailer/SMTP.php';
require_once __DIR__ . '/phpmailer/Exception.php';

/**
 * CommentVerify - Typecho评论验证插件
 * 
 * 功能特点：
 * - 评论需要邮件验证才会通过审核
 * - 支持中文/英文自动识别
 * - 邮件包含昵称、邮箱、评论内容
 * - Token 48小时有效
 * - 支持最多3次重新发送
 * - 使用PHPMailer稳定SMTP
 * - 审核成功自动跳转到文章页面
 * - 后台可查看日志
 * 
 * @author AI Assistant
 * @version 1.0.0
 */

class CommentVerify_Plugin implements Typecho_Plugin_Interface
{
    const SECRET_KEY = 'CHANGE_THIS_SECRET_KEY_20241116';
    const TOKEN_EXPIRE = 48 * 3600; // 48小时
    const MAX_RESEND = 3; // 最多重发3次

    /**
     * 插件激活
     */
    public static function activate()
    {
        try {
            // 检查PHP版本
            if (version_compare(PHP_VERSION, '5.6.0', '<')) {
                throw new Typecho_Plugin_Exception('CommentVerify 插件需要 PHP 5.6.0 或更高版本');
            }

            // 检查必需的PHP扩展
            if (!extension_loaded('openssl')) {
                throw new Typecho_Plugin_Exception('CommentVerify 插件需要 openssl 扩展');
            }

            if (!extension_loaded('mbstring')) {
                throw new Typecho_Plugin_Exception('CommentVerify 插件需要 mbstring 扩展');
            }

            $db = Typecho_Db::get();
            $prefix = $db->getPrefix();

            // 检查数据库连接
            if (!$db->isConnected()) {
                throw new Typecho_Plugin_Exception('数据库连接失败');
            }

            // 创建Token表
            $sql = "CREATE TABLE IF NOT EXISTS `{$prefix}comment_token` (
                `id` INT AUTO_INCREMENT PRIMARY KEY,
                `comment_id` INT NOT NULL,
                `token_hash` CHAR(64) NOT NULL,
                `created` INT NOT NULL,
                `resend` INT NOT NULL DEFAULT 0,
                INDEX `idx_comment_id` (`comment_id`),
                INDEX `idx_token_hash` (`token_hash`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
            
            try {
                $db->query($sql);
            } catch (Exception $e) {
                throw new Typecho_Plugin_Exception('创建数据表失败: ' . $e->getMessage());
            }

            // 注册评论完成钩子
            Typecho_Plugin::factory('Widget_Feedback')->finishComment = ['CommentVerify_Plugin', 'sendVerifyEmail'];
            
            // 注册验证动作
            Helper::addAction('verify-comment', 'CommentVerify_Action');
            
            // 添加后台管理菜单
            Helper::addPanel(1, 'CommentVerify/log.php', '评论验证日志', '查看验证日志', 'administrator');

            return _t('CommentVerify 插件已成功激活');
            
        } catch (Typecho_Plugin_Exception $e) {
            // 插件异常直接抛出
            throw $e;
        } catch (Exception $e) {
            // 其他异常转换为插件异常
            throw new Typecho_Plugin_Exception('插件激活失败: ' . $e->getMessage());
        }
    }

    /**
     * 插件禁用
     */
    public static function deactivate()
    {
        try {
            // 移除验证动作
            Helper::removeAction('verify-comment');
            
            // 移除后台管理菜单
            Helper::removePanel(1, 'CommentVerify/log.php');
            
            // 注意：不删除数据表，保留历史数据
            return _t('CommentVerify 插件已成功禁用');
        } catch (Exception $e) {
            throw new Typecho_Plugin_Exception('插件禁用失败: ' . $e->getMessage());
        }
    }

    /**
     * 插件配置表单
     */
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        // SMTP主机
        $smtpHost = new Typecho_Widget_Helper_Form_Element_Text('smtpHost', 
            NULL, '', 
            _t('SMTP 主机'), 
            _t('例如：smtp.gmail.com 或 smtp.qq.com')
        );
        $form->addInput($smtpHost);

        // SMTP端口
        $smtpPort = new Typecho_Widget_Helper_Form_Element_Text('smtpPort', 
            NULL, '587', 
            _t('SMTP 端口'), 
            _t('常用端口：587（TLS）、465（SSL）、25（非加密）')
        );
        $form->addInput($smtpPort);

        // SMTP用户名
        $smtpUser = new Typecho_Widget_Helper_Form_Element_Text('smtpUser', 
            NULL, '', 
            _t('SMTP 用户名'), 
            _t('通常是完整的邮箱地址')
        );
        $form->addInput($smtpUser);

        // SMTP密码
        $smtpPass = new Typecho_Widget_Helper_Form_Element_Password('smtpPass', 
            NULL, '', 
            _t('SMTP 密码'), 
            _t('注意：某些邮箱需要使用应用专用密码')
        );
        $form->addInput($smtpPass);

        // 发件邮箱
        $fromMail = new Typecho_Widget_Helper_Form_Element_Text('fromMail', 
            NULL, '', 
            _t('发件邮箱地址'), 
            _t('发送验证邮件的邮箱地址')
        );
        $form->addInput($fromMail);

        // 发件人名称
        $fromName = new Typecho_Widget_Helper_Form_Element_Text('fromName', 
            NULL, 'CommentVerify', 
            _t('发件显示名称'), 
            _t('邮件中显示的发件人名称')
        );
        $form->addInput($fromName);

        // 邮件主题前缀
        $subjectPrefix = new Typecho_Widget_Helper_Form_Element_Text('subjectPrefix', 
            NULL, '[评论验证]', 
            _t('邮件主题前缀'), 
            _t('邮件主题的标识前缀')
        );
        $form->addInput($subjectPrefix);
    }

    /**
     * 个人配置
     */
    public static function personalConfig(Typecho_Widget_Helper_Form $form)
    {
        // 个人配置留空
    }

    /**
     * 获取语言文本
     */
    public static function lang($key)
    {
        // 检测用户语言偏好
        $lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? "en", 0, 2);
        
        // 根据语言加载对应的语言包
        if ($lang === 'zh') {
            $arr = include __DIR__ . '/lang/zh_CN.php';
        } else {
            $arr = include __DIR__ . '/lang/en_US.php';
        }
        
        return $arr[$key] ?? $key;
    }

    /**
     * 发送验证邮件
     */
    public static function sendVerifyEmail($comment)
    {
        // 获取评论信息
        $cid = $comment->coid;
        $email = $comment->mail;
        $author = $comment->author;
        $content = $comment->text;
        $parent = $comment->parent;

        // 验证邮箱格式
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            self::log("无效邮箱格式: $email / CID=$cid");
            return $comment;
        }

        $db = Typecho_Db::get();
        
        try {
            // 生成随机token
            $random = bin2hex(random_bytes(32));
            $token = hash_hmac('sha256', $random, self::SECRET_KEY);

            // 插入token记录
            $db->query($db->insert('table.comment_token')->rows([
                'comment_id' => $cid,
                'token_hash' => $token,
                'created' => time(),
                'resend' => 0
            ]));

            // 发送邮件
            self::sendMail($email, $author, $content, $cid, $random, $parent);
            
            // 记录日志
            self::log("发送验证邮件 → $email / CID=$cid / 作者=$author");
            
            // 设置评论为待审核状态
            $db->query($db->update('table.comments')->rows(['status' => 'waiting'])->where('coid = ?', $cid));

        } catch (Exception $e) {
            self::log("发送邮件失败: " . $e->getMessage() . " / CID=$cid");
        }

        return $comment;
    }

    /**
     * 使用PHPMailer发送邮件
     */
    public static function sendMail($email, $author, $content, $cid, $random, $parent = 0)
    {
        $opt = Helper::options()->plugin('CommentVerify');
        $verifyUrl = Helper::options()->siteUrl . "index.php/action/verify-comment?token={$random}";

        // 读取邮件模板
        $html = file_get_contents(__DIR__ . "/mail_template.html");
        
        // 替换模板变量
        $html = str_replace("{{site_title}}", Helper::options()->title, $html);
        $html = str_replace("{{site_url}}", Helper::options()->siteUrl, $html);
        $html = str_replace("{{verify_url}}", $verifyUrl, $html);
        $html = str_replace("{{author}}", htmlspecialchars($author), $html);
        $html = str_replace("{{email}}", htmlspecialchars($email), $html);
        $html = str_replace("{{content}}", nl2br(htmlspecialchars($content)), $html);
        $html = str_replace("{{comment_id}}", $cid, $html);
        $html = str_replace("{{expire_hours}}", intval(self::TOKEN_EXPIRE / 3600), $html);
        
        // 设置邮件主题
        $subject = ($opt->subjectPrefix ? $opt->subjectPrefix . ' ' : '') . self::lang('email_subject');

        $mail = new PHPMailer\PHPMailer\PHPMailer();
        
        try {
            // SMTP配置
            $mail->isSMTP();
            $mail->Host = $opt->smtpHost;
            $mail->SMTPAuth = true;
            $mail->Username = $opt->smtpUser;
            $mail->Password = $opt->smtpPass;
            $mail->Port = $opt->smtpPort;
            
            // 根据端口选择加密方式
            if ($opt->smtpPort == 465) {
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($opt->smtpPort == 587) {
                $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
            }

            // 发件人配置
            $mail->setFrom($opt->fromMail, $opt->fromName);
            $mail->addAddress($email, $author);
            
            // 邮件内容
            $mail->isHTML(true);
            $mail->CharSet = 'UTF-8';
            $mail->Subject = $subject;
            $mail->Body = $html;
            
            // 添加纯文本版本
            $textContent = self::lang('email_subject') . "\n\n";
            $textContent .= self::lang('email_desc') . "\n";
            $textContent .= $verifyUrl . "\n\n";
            $textContent .= "评论信息：\n";
            $textContent .= "昵称：" . $author . "\n";
            $textContent .= "邮箱：" . $email . "\n";
            $textContent .= "内容：" . strip_tags($content) . "\n";
            $mail->AltBody = $textContent;

            // 发送邮件
            $mail->send();
            
        } catch (Exception $e) {
            throw new Exception("邮件发送失败: " . $mail->ErrorInfo);
        }
    }

    /**
     * 记录日志
     */
    public static function log($msg)
    {
        $logFile = __DIR__ . "/logs.txt";
        $timestamp = date("Y-m-d H:i:s");
        $logEntry = "[$timestamp] $msg\n";
        
        // 确保日志目录可写
        if (!is_writable(dirname($logFile))) {
            return;
        }
        
        // 写入日志
        file_put_contents($logFile, $logEntry, FILE_APPEND | LOCK_EX);
        
        // 限制日志文件大小（最大1MB）
        if (file_exists($logFile) && filesize($logFile) > 1024 * 1024) {
            $content = file_get_contents($logFile);
            $lines = explode("\n", $content);
            // 保留最后100行
            $lastLines = array_slice($lines, -100);
            file_put_contents($logFile, implode("\n", $lastLines));
        }
    }

    /**
     * 重新发送验证邮件
     */
    public static function resendVerifyEmail($commentId)
    {
        $db = Typecho_Db::get();
        
        // 获取token记录
        $tokenRow = $db->fetchRow($db->select()
            ->from('table.comment_token')
            ->where('comment_id = ?', $commentId));
        
        if (!$tokenRow) {
            return false;
        }
        
        // 检查重发次数
        if ($tokenRow['resend'] >= self::MAX_RESEND) {
            return false;
        }
        
        // 获取评论信息
        $comment = $db->fetchRow($db->select()
            ->from('table.comments')
            ->where('coid = ?', $commentId));
        
        if (!$comment) {
            return false;
        }
        
        try {
            // 更新重发次数
            $db->query($db->update('table.comment_token')
                ->rows(['resend' => $tokenRow['resend'] + 1])
                ->where('comment_id = ?', $commentId));
            
            // 重新生成随机token
            $random = bin2hex(random_bytes(32));
            $newToken = hash_hmac('sha256', $random, self::SECRET_KEY);
            
            // 更新token
            $db->query($db->update('table.comment_token')
                ->rows(['token_hash' => $newToken, 'created' => time()])
                ->where('comment_id = ?', $commentId));
            
            // 发送邮件
            self::sendMail($comment['mail'], $comment['author'], $comment['text'], $commentId, $random, $comment['parent']);
            
            self::log("重新发送验证邮件 → {$comment['mail']} / CID=$commentId / 次数=" . ($tokenRow['resend'] + 1));
            
            return true;
            
        } catch (Exception $e) {
            self::log("重新发送邮件失败: " . $e->getMessage() . " / CID=$commentId");
            return false;
        }
    }
}