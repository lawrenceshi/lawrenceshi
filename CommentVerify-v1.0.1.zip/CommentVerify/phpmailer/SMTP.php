<?php
/**
 * PHPMailer - PHP email creation and transport class.
 * PHP Version 5.5.
 *
 * @see       https://github.com/PHPMailer/PHPMailer/ The PHPMailer GitHub project
 *
 * @author    Marcus Bointon (Synchro/coolbru) <phpmailer@synchromedia.co.uk>
 * @author    Jim Jagielski (jimjag) <jimjag@gmail.com>
 * @author    Andy Prevost (codeworxtech) <codeworxtech@users.sourceforge.net>
 * @author    Brent R. Matzelle (original founder)
 * @copyright 2012 - 2020 Marcus Bointon
 * @copyright 2010 - 2012 Jim Jagielski
 * @copyright 2004 - 2009 Andy Prevost
 * @license   http://www.gnu.org/copyleft/lesser.html GNU Lesser General Public License
 * @note      This program is distributed in the hope that it will be useful - WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.
 */

namespace PHPMailer\PHPMailer;

/**
 * PHPMailer - PHP email creation and transport class.
 *
 * @author  Marcus Bointon <phpmailer@synchromedia.co.uk>
 * @author  Jim Jagielski <jimjag@gmail.com>
 * @author  Andy Prevost <codeworxtech@users.sourceforge.net>
 * @author  Brent R. Matzelle
 */
class SMTP
{
    const VERSION = '6.8.0';
    const LE = "\r\n";
    const DEFAULT_PORT = 25;
    const MAX_LINE_LENGTH = 998;
    const MAX_REPLY_LENGTH = 512;
    const DEBUG_OFF = 0;
    const DEBUG_CLIENT = 1;
    const DEBUG_SERVER = 2;
    const DEBUG_CONNECTION = 3;
    const DEBUG_LOWLEVEL = 4;

    /**
     * The PHPMailer SMTP version number.
     *
     * @var string
     */
    public $Version = self::VERSION;

    /**
     * SMTP server port number.
     *
     * @var int
     */
    public $Port = self::DEFAULT_PORT;

    /**
     * The timeout value for connection, in seconds.
     * Default of 5 minutes (300sec) is from RFC2821 section 4.5.3.2.
     * This needs to be quite high to function correctly with hosts using greetdelay as an anti-spam measure.
     *
     * @var int
     */
    public $Timeout = 300;

    /**
     * SMTP reply line ending.
     * Do not change, SMTP is specified to use \r\n, see RFC5321 sec 2.3.9.
     *
     * @var string
     */
    public $LE = self::LE;

    /**
     * The encryption system to use - ssl (deprecated) or tls.
     *
     * @var string
     */
    public $SMTPSecure = '';

    /**
     * Whether to use SMTP authentication.
     * Uses the Username and Password properties.
     *
     * @var bool
     */
    public $SMTPAuth = false;

    /**
     * SMTP username.
     * Default of null for backwards compatibility.
     *
     * @var null|string
     */
    public $Username = '';

    /**
     * SMTP password.
     * Default of null for backwards compatibility.
     *
     * @var null|string
     */
    public $Password = '';

    /**
     * SMTP auth type.
     * Options are CRAM-MD5, LOGIN, PLAIN, XOAUTH2, attempted in that order if not specified.
     *
     * @var string
     */
    public $AuthType = '';

    /**
     * SMTP realm.
     * Used for NTLM auth.
     *
     * @var string
     */
    public $Realm = '';

    /**
     * SMTP workstation.
     * Used for NTLM auth.
     *
     * @var string
     */
    public $Workstation = '';

    /**
     * The SMTP server hostname.
     * Default of 'localhost'.
     *
     * @var string
     */
    public $Host = 'localhost';

    /**
     * The server 'hello' SMTP command.
     * Default of 'localhost'.
     *
     * @var string
     */
    public $Helo = '';

    /**
     * The connection timeout, in seconds.
     * Default of 5 minutes (300sec) is from RFC2821 section 4.5.3.2.
     * This needs to be quite high to function correctly with hosts using greetdelay as an anti-spam measure.
     *
     * @var int
     */
    public $ConnectTimeout = 30;

    /**
     * The timeout for SMTP commands, in seconds.
     * Default of 5 minutes (300sec) is from RFC2821 section 4.5.3.2.
     * This needs to be quite high to function correctly with hosts using greetdelay as an anti-spam measure.
     *
     * @var int
     */
    public $Timeout = 300;

    /**
     * Comma separated list of DSN notifications.
     * 'NEVER' under no circumstances a DSN should be returned to the sender.
     *         If you send a DSN it will be sent to the sender (useful for testing).
     * 'SUCCESS' will send a DSN on successful delivery.
     * 'FAILURE' will send a DSN on failed delivery.
     * 'DELAY' will send a DSN on delayed delivery.
     * 'SUCCESS,FAILURE' will send a DSN on successful delivery or failed delivery.
     * 'SUCCESS,DELAY' will send a DSN on successful delivery or delayed delivery.
     * 'FAILURE,DELAY' will send a DSN on failed delivery or delayed delivery.
     * 'SUCCESS,FAILURE,DELAY' will send a DSN on any outcome.
     *
     * @var string
     */
    public $dsn = '';

    /**
     * The SMTP server timeout in seconds.
     * Default of 300 seconds is from RFC 2821 section 4.5.3.2.
     *
     * @var int
     */
    public $Timeout = 300;

    /**
     * SMTP class debug output mode.
     * Debug output level.
     * Options:
     * @see SMTP::DEBUG_OFF: No output
     * @see SMTP::DEBUG_CLIENT: Client messages
     * @see SMTP::DEBUG_SERVER: Client and server messages
     * @see SMTP::DEBUG_CONNECTION: As SERVER plus connection status
     * @see SMTP::DEBUG_LOWLEVEL: Noisy, low-level data output, rarely needed
     *
     * @var int
     */
    public $do_debug = self::DEBUG_OFF;

    /**
     * Whether debug output is echoed to the screen or returned.
     * If true, debug output is echoed to the screen.
     * If false, debug output is returned as a string.
     *
     * @var bool
     */
    public $Debugoutput = 'echo';

    /**
     * Whether to use VERP.
     *
     * @var bool
     */
    public $do_verp = false;

    /**
     * The timeout value for connection, in seconds.
     * Default of 5 minutes (300sec) is from RFC2821 section 4.5.3.2.
     * This needs to be quite high to function correctly with hosts using greetdelay as an anti-spam measure.
     *
     * @var int
     */
    public $Timeout = 300;

    /**
     * SMTP reply line ending.
     * Do not change, SMTP is specified to use \r\n, see RFC5321 sec 2.3.9.
     *
     * @var string
     */
    public $LE = self::LE;

    /**
     * The socket for the server connection.
     *
     * @var ?resource
     */
    protected $smtp_conn;

    /**
     * Error information, if any, for the last SMTP command.
     *
     * @var array
     */
    protected $error = [
        'error' => '',
        'detail' => '',
        'smtp_code' => '',
        'smtp_code_ex' => '',
    ];

    /**
     * The reply the server sent to us for HELO.
     * If null, no HELO string has yet been received.
     * This property is used to return the HELO response from the server.
     * This is used to determine if the server supports certain features.
     *
     * @var string|null
     */
    protected $helo_rply = null;

    /**
     * The most recent reply from the server.
     *
     * @var string
     */
    protected $last_reply = '';

    /**
     * The server hostname or IP address.
     *
     * @var string
     */
    protected $host = '';

    /**
     * The server port.
     *
     * @var int
     */
    protected $port = 0;

    /**
     * The timeout for the socket connection.
     *
     * @var int
     */
    protected $timeout = 0;

    /**
     * The timeout for the socket connection.
     *
     * @var int
     */
    protected $time_limit = 0;

    /**
     * The socket for the server connection.
     *
     * @var ?resource
     */
    protected $smtp_conn;

    /**
     * Error information, if any, for the last SMTP command.
     *
     * @var array
     */
    protected $error = [
        'error' => '',
        'detail' => '',
        'smtp_code' => '',
        'smtp_code_ex' => '',
    ];

    /**
     * The reply the server sent to us for HELO.
     * If null, no HELO string has yet been received.
     * This property is used to return the HELO response from the server.
     * This is used to determine if the server supports certain features.
     *
     * @var string|null
     */
    protected $helo_rply = null;

    /**
     * The most recent reply from the server.
     *
     * @var string
     */
    protected $last_reply = '';

    /**
     * The server hostname or IP address.
     *
     * @var string
     */
    protected $host = '';

    /**
     * The server port.
     *
     * @var int
     */
    protected $port = 0;

    /**
     * The timeout for the socket connection.
     *
     * @var int
     */
    protected $timeout = 0;

    /**
     * The timeout for the socket connection.
     *
     * @var int
     */
    protected $time_limit = 0;

    /**
     * Connect to an SMTP server.
     *
     * @param string $host    SMTP server hostname or IP
     * @param int    $port    SMTP server port
     * @param int    $timeout Connection timeout
     * @param array  $options An array of options compatible with stream_context_create()
     *
     * @return bool
     */
    public function connect($host, $port = null, $timeout = 30, $options = [])
    {
        // Clear errors
        $this->setError('');
        
        // Store host and port
        $this->host = $host;
        $this->port = $port ?: $this->Port;
        $this->timeout = $timeout;
        
        // Connect to the SMTP server
        $errno = 0;
        $errstr = '';
        
        // Create socket context
        $context = stream_context_create($options);
        
        // Connect
        $this->smtp_conn = @stream_socket_client(
            $this->host . ':' . $this->port,
            $errno,
            $errstr,
            $timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        // Verify connection
        if (!is_resource($this->smtp_conn)) {
            $this->setError(
                'Failed to connect to server',
                $errstr,
                (string) $errno
            );
            
            if ($this->do_debug >= self::DEBUG_CONNECTION) {
                $this->edebug(
                    'SMTP ERROR: ' . $this->error['error'] . ': ' . $errstr . " (" . $errno . ")"
                );
            }
            
            return false;
        }
        
        // Set timeout
        stream_set_timeout($this->smtp_conn, $timeout);
        
        // Get server response
        $announce = $this->get_lines();
        
        if ($this->do_debug >= self::DEBUG_SERVER) {
            $this->edebug('SMTP -> FROM SERVER:' . $announce);
        }
        
        return true;
    }

    /**
     * Initiate a TLS (encrypted) session.
     *
     * @return bool
     */
    public function startTLS()
    {
        if (!$this->sendCommand('STARTTLS', 'STARTTLS', 220)) {
            return false;
        }

        // Allow the best TLS version we can
        $crypto_method = STREAM_CRYPTO_METHOD_TLS_CLIENT;

        // PHP 5.6.7 dropped inclusion of TLS 1.1 and 1.2 in STREAM_CRYPTO_METHOD_TLS_CLIENT
        // so add them back in manually if we can
        if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
            $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
            $crypto_method |= STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT;
        }

        // Begin encrypted connection
        if (!stream_socket_enable_crypto(
            $this->smtp_conn,
            true,
            $crypto_method
        )) {
            return false;
        }

        return true;
    }

    /**
     * Perform SMTP authentication.
     * Must be run after hello() and before mail() or recipient() calls.
     *
     * @param string $username The user name
     * @param string $password The password
     * @param string $authtype The auth type (CRAM-MD5, LOGIN, PLAIN, XOAUTH2)
     * @param string $realm    The auth realm for NTLM
     * @param string $workstation The auth workstation for NTLM
     *
     * @return bool True if successfully authenticated
     */
    public function authenticate(
        $username,
        $password,
        $authtype = null,
        $realm = '',
        $workstation = ''
    ) {
        if (!$this->server_caps) {
            $this->setError('Authentication is not allowed before HELO/EHLO');
            
            return false;
        }

        if (array_key_exists('EHLO', $this->server_caps)) {
            // Start authentication
            if (!$this->sendCommand('AUTH', 'AUTH', 334)) {
                return false;
            }
        } elseif (array_key_exists('HELO', $this->server_caps)) {
            $this->setError('HELO does not support authentication');
            
            return false;
        } else {
            $this->setError('HELO or EHLO command was not sent');
            
            return false;
        }

        // If no auth type is supplied, try to get it from the server
        if (null === $authtype) {
            if (array_key_exists('AUTH', $this->server_caps)) {
                if (in_array('CRAM-MD5', $this->server_caps['AUTH'])) {
                    $authtype = 'CRAM-MD5';
                } elseif (in_array('LOGIN', $this->server_caps['AUTH'])) {
                    $authtype = 'LOGIN';
                } elseif (in_array('PLAIN', $this->server_caps['AUTH'])) {
                    $authtype = 'PLAIN';
                } elseif (in_array('XOAUTH2', $this->server_caps['AUTH'])) {
                    $authtype = 'XOAUTH2';
                }
            } else {
                $this->setError('No supported authentication methods found');
                
                return false;
            }
        }

        switch ($authtype) {
            case 'PLAIN':
                // Start authentication
                if (!$this->sendCommand('AUTH', 'AUTH PLAIN', 334)) {
                    return false;
                }
                
                // Send encoded username and password
                if (!$this->sendCommand(
                    'User & Password',
                    base64_encode("\0" . $username . "\0" . $password),
                    235
                )) {
                    return false;
                }
                break;
            case 'LOGIN':
                // Start authentication
                if (!$this->sendCommand('AUTH', 'AUTH LOGIN', 334)) {
                    return false;
                }
                
                // Send username
                if (!$this->sendCommand('Username', base64_encode($username), 334)) {
                    return false;
                }
                
                // Send password
                if (!$this->sendCommand('Password', base64_encode($password), 235)) {
                    return false;
                }
                break;
            case 'CRAM-MD5':
                // Start authentication
                if (!$this->sendCommand('AUTH CRAM-MD5', 'AUTH CRAM-MD5', 334)) {
                    return false;
                }
                
                // Get the challenge
                $challenge = base64_decode($this->last_reply);
                
                // Build the response
                $response = $username . ' ' . $this->hmac($challenge, $password);
                
                // Send encoded credentials
                if (!$this->sendCommand('Username', base64_encode($response), 235)) {
                    return false;
                }
                break;
            case 'XOAUTH2':
                //If the OAuth instance is not set, we can't authenticate
                if (null === $this->oauth) {
                    $this->setError('XOAUTH2 authentication requires an OAuth2 client instance');
                    
                    return false;
                }
                
                $oauth = $this->oauth;
                $oauth->setUserEmail($username);
                
                // Start authentication
                if (!$this->sendCommand('AUTH', 'AUTH XOAUTH2 ' . base64_encode($oauth->getOauth64()), 235)) {
                    return false;
                }
                break;
            default:
                $this->setError("Authentication method \"$authtype\" is not supported");
                
                return false;
        }

        return true;
    }

    /**
     * HMAC implementation for CRAM-MD5 authentication.
     *
     * @param string $data The data to hash
     * @param string $key  The key to hash with
     *
     * @return string The hashed data
     */
    protected function hmac($data, $key)
    {
        if (function_exists('hash_hmac')) {
            return hash_hmac('md5', $data, $key);
        }

        // RFC 2104 HMAC implementation for php.
        // Creates equivalent of hash_hmac('md5', $data, $key)

        $bytelen = 64; // byte length for md5
        if (strlen($key) > $bytelen) {
            $key = pack('H*', md5($key));
        }

        $key = str_pad($key, $bytelen, chr(0x00));
        $ipad = str_repeat(chr(0x36), $bytelen);
        $opad = str_repeat(chr(0x5c), $bytelen);
        $inner = pack('H*', md5(($key ^ $ipad) . $data));
        $digest = md5(($key ^ $opad) . $inner);

        return $digest;
    }

    /**
     * Send an SMTP command.
     *
     * @param string $command The command to send
     * @param string $commandstring The full command string to send
     * @param int    $expect The expected response code
     *
     * @return bool True if the command was accepted
     */
    protected function sendCommand($command, $commandstring, $expect)
    {
        if (!$this->connected()) {
            $this->setError("Called $command without being connected");

            return false;
        }

        $this->client_send($commandstring . static::LE, $command);

        $reply = $this->get_lines();
        $code = substr($reply, 0, 3);

        if ($this->do_debug >= self::DEBUG_SERVER) {
            $this->edebug('SMTP -> FROM SERVER:' . $reply);
        }

        if ($code != $expect) {
            $this->setError(
                "$command command failed",
                $reply,
                $code
            );
            
            if ($this->do_debug >= self::DEBUG_SERVER) {
                $this->edebug('SMTP ERROR: ' . $this->error['error'] . ': ' . $reply);
            }
            
            return false;
        }

        $this->setError('');

        return true;
    }

    /**
     * Send an SMTP data command.
     *
     * @return bool
     */
    public function data()
    {
        return $this->sendCommand('DATA', 'DATA', 354);
    }

    /**
     * Send the SMTP EHLO or HELO command.
     * The first parameter is the name of the sending server.
     *
     * @param string $host The hostname to use for the HELO/EHLO command
     *
     * @return bool
     */
    public function hello($host = '')
    {
        // Try extended hello first (RFC 5321)
        if ($this->sendHello('EHLO', $host)) {
            return true;
        }

        // Some servers won't try EHLO, so fall back to HELO
        if (substr($this->Version, 0, 1) == '5') {
            $this->setError('HELO was accepted, but no HELO keyword(s) were returned');
            
            return false;
        }

        return $this->sendHello('HELO', $host);
    }

    /**
     * Send an SMTP HELO or EHLO command.
     * Low-level interface to sendHello().
     *
     * @param string $hello The HELO string to use
     * @param string $host  The hostname to use
     *
     * @return bool
     */
    protected function sendHello($hello, $host)
    {
        $noerror = $this->sendCommand($hello, $hello . ' ' . $host, 250);
        $this->helo_rply = $this->last_reply;
        
        if ($noerror) {
            $this->parseHelloFields($hello);
        } else {
            if ($this->do_debug >= self::DEBUG_SERVER) {
                $this->edebug('SMTP ERROR: ' . $this->error['error']);
            }
        }

        return $noerror;
    }

    /**
     * Parse a reply to HELO/EHLO command to discover server extensions.
     * In case of HELO, the only parameter that can be discovered is the server name.
     *
     * @param string $type `HELO` or `EHLO`
     */
    protected function parseHelloFields($type)
    {
        $this->server_caps = [];
        $lines = explode("\n", $this->helo_rply);

        foreach ($lines as $n => $s) {
            $s = trim(substr($s, 4));
            $this->server_caps[$n] = $s;

            if ($n === 0) {
                $this->server_caps['EHLO'] = $s;
            }

            $fields = explode(' ', $s);
            if (!empty($fields)) {
                if (!$this->server_caps) {
                    $this->server_caps = [];
                }

                $this->server_caps[$fields[0]] = array_slice($fields, 1);
            }
        }
    }

    /**
     * Send an SMTP mail command.
     * Starts a mail transaction from the email address specified in $from.
     * Returns true if successful or false otherwise.
     * If the mail command is sent successfully, the mail transaction is started.
     *
     * @param string $from The email address to send from
     *
     * @return bool
     */
    public function mail($from)
    {
        $useVerp = ($this->do_verp ? 'XVERP' : '');

        return $this->sendCommand(
            'MAIL FROM',
            'MAIL FROM:<' . $from . '>' . $useVerp,
            250
        );
    }

    /**
     * Send an SMTP quit command.
     * Closes the socket if there is no error or the $close_on_error argument is true.
     *
     * @param bool $close_on_error Should the connection close?
     *
     * @return bool
     */
    public function quit($close_on_error = true)
    {
        $noerror = $this->sendCommand('QUIT', 'QUIT', 221);
        $err = $this->error;

        if ($noerror || $close_on_error) {
            $this->close();
        }

        // Get any remaining response on the buffer
        $this->get_lines();

        return $noerror;
    }

    /**
     * Send an SMTP recipient command.
     * Sets the TO argument to $toaddr.
     * Returns true if the recipient was accepted false if it was rejected.
     *
     * @param string $toaddr The email address to send to
     * @param string $dsn    Comma separated list of DSN notifications
     *
     * @return bool
     */
    public function recipient($toaddr, $dsn = '')
    {
        if (!empty($dsn)) {
            $dsn = strtoupper($dsn);
            $notify = [];

            if (strpos($dsn, 'NEVER') !== false) {
                $notify[] = 'NEVER';
            } else {
                foreach (['SUCCESS', 'FAILURE', 'DELAY'] as $value) {
                    if (strpos($dsn, $value) !== false) {
                        $notify[] = $value;
                    }
                }
            }

            if (!empty($notify)) {
                $dsn = ' NOTIFY=' . implode(',', $notify);
            }
        }

        return $this->sendCommand(
            'RCPT TO',
            'RCPT TO:<' . $toaddr . '>' . $dsn,
            [250, 251]
        );
    }

    /**
     * Send an SMTP reset command.
     * Resets the current mail transaction.
     *
     * @return bool
     */
    public function reset()
    {
        return $this->sendCommand('RSET', 'RSET', 250);
    }

    /**
     * Send a command to the server and get a reply back.
     *
     * @param string $command The command to send
     * @param string $data    The data to send
     *
     * @return string
     */
    public function send_and_mail($command, $data)
    {
        $this->client_send($command . $data . static::LE);

        return $this->get_lines();
    }

    /**
     * Send the data to the server.
     *
     * @param string $data    The data to send
     * @param string $command The command to send
     *
     * @return bool
     */
    public function client_send($data, $command = '')
    {
        $this->last_reply = '';

        if ($this->do_debug >= self::DEBUG_CLIENT) {
            $this->edebug('SMTP -> FROM CLIENT:' . $data);
        }

        return fwrite($this->smtp_conn, $data) !== false;
    }

    /**
     * Get the latest error.
     *
     * @return array
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * Get SMTP extensions available on the server.
     *
     * @return array|null
     */
    public function getServerExtList()
    {
        return $this->server_caps;
    }

    /**
     * Get metadata about the SMTP server.
     *
     * @param string $name The name of the extension to check
     *
     * @return mixed
     */
    public function getServerExt($name)
    {
        if (!$this->server_caps) {
            $this->setError('No HELO/EHLO was sent');

            return null;
        }

        if (!array_key_exists($name, $this->server_caps)) {
            if ($name == 'HELO') {
                return $this->server_caps['EHLO'];
            }
            
            if ($name == 'EHLO' || array_key_exists('EHLO', $this->server_caps)) {
                return false;
            }

            $this->setError('HELO/EHLO was not accepted');

            return null;
        }

        return $this->server_caps[$name];
    }

    /**
     * Get the last reply from the server.
     *
     * @return string
     */
    public function getLastReply()
    {
        return $this->last_reply;
    }

    /**
     * Get the current error.
     *
     * @return string
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * Set error details.
     *
     * @param string $message The error message
     * @param string $detail  Optional details
     * @param string $smtp_code  Optional SMTP code
     * @param string $smtp_code_ex Optional extended SMTP code
     */
    protected function setError($message, $detail = '', $smtp_code = '', $smtp_code_ex = '')
    {
        $this->error = [
            'error' => $message,
            'detail' => $detail,
            'smtp_code' => $smtp_code,
            'smtp_code_ex' => $smtp_code_ex,
        ];
    }

    /**
     * Check if the SMTP connection is connected.
     *
     * @return bool
     */
    public function connected()
    {
        if (is_resource($this->smtp_conn)) {
            $sock_status = stream_get_meta_data($this->smtp_conn);
            
            if ($sock_status['eof']) {
                $this->edebug(
                    'SMTP NOTICE: EOF caught while checking if connected'
                );
                $this->close();

                return false;
            }

            return true;
        }

        return false;
    }

    /**
     * Close the socket and clean up the state of the class.
     * It's not considered successful to close a socket that is not connected.
     *
     * @return void
     */
    public function close()
    {
        $this->setError('');
        $this->server_caps = null;
        $this->helo_rply = null;

        if (is_resource($this->smtp_conn)) {
            fclose($this->smtp_conn);
        }

        $this->smtp_conn = null;
    }

    /**
     * Get lines from the server.
     *
     * @return string
     */
    public function get_lines()
    {
        // If the connection is bad, give up straight away
        if (!$this->connected()) {
            return '';
        }

        $data = '';
        $endtime = 0;

        // Set timeout
        stream_set_timeout($this->smtp_conn, $this->Timeout);

        if ($this->Timelimit > 0) {
            $endtime = time() + $this->Timelimit;
        }

        while (is_resource($this->smtp_conn) && !feof($this->smtp_conn)) {
            $str = @fgets($this->smtp_conn, self::MAX_REPLY_LENGTH);
            $this->edebug('SMTP -> get_lines(): $data was "' . $data . '"', self::DEBUG_LOWLEVEL);
            $this->edebug('SMTP -> get_lines(): $str is  "' . $str . '"', self::DEBUG_LOWLEVEL);
            $data .= $str;

            // If response is done, break out
            if (isset($str[3]) && $str[3] === ' ') {
                break;
            }

            // Timed-out? Log and break
            $info = stream_get_meta_data($this->smtp_conn);
            if ($info['timed_out']) {
                $this->edebug(
                    'SMTP -> get_lines(): timed-out (' . $this->Timeout . ' sec)',
                    self::DEBUG_LOWLEVEL
                );
                break;
            }

            // Now check if reads took too long
            if ($endtime && time() > $endtime) {
                $this->edebug(
                    'SMTP -> get_lines(): timelimit reached (' .
                    $this->Timelimit . ' sec)',
                    self::DEBUG_LOWLEVEL
                );
                break;
            }
        }

        return $data;
    }

    /**
     * Set debug output method.
     *
     * @param string|callable $method The name of the mechanism to use for debug output,
     *                                or a callable to handle it
     *
     * @return void
     */
    public function setDebugOutput($method = 'echo')
    {
        $this->Debugoutput = $method;
    }

    /**
     * Get debug output method.
     *
     * @return string
     */
    public function getDebugOutput()
    {
        return $this->Debugoutput;
    }

    /**
     * Set debug output level.
     *
     * @param int $level The debug level
     *
     * @return void
     */
    public function setDebugLevel($level = 0)
    {
        $this->do_debug = $level;
    }

    /**
     * Get debug output level.
     *
     * @return int
     */
    public function getDebugLevel()
    {
        return $this->do_debug;
    }

    /**
     * Set SMTP timeout.
     *
     * @param int $timeout The timeout in seconds
     *
     * @return void
     */
    public function setTimeout($timeout = 0)
    {
        $this->Timeout = $timeout;
    }

    /**
     * Get SMTP timeout.
     *
     * @return int
     */
    public function getTimeout()
    {
        return $this->Timeout;
    }

    /**
     * Reports an error number and string.
     *
     * @param int    $errno   The error number returned by the socket
     * @param string $errstr  The error message returned by the socket
     * @param string $errfile The file the error occurred in
     * @param int    $errline The line number the error occurred on
     *
     * @return void
     */
    protected function errorHandler($errno, $errstr, $errfile, $errline)
    {
        $notice = 'Connection: failed to connect to server.';
        $this->setError(
            $notice,
            $errstr,
            (string) $errno
        );
        
        if ($this->do_debug >= self::DEBUG_CONNECTION) {
            $this->edebug(
                $notice . ' Error number ' . $errno . '. "Error notice: ' . $errstr . '"'
            );
        }
    }

    /**
     * Will return the server's greeting string.
     *
     * @return string
     */
    public function getServerExt($name)
    {
        if (!$this->server_caps) {
            $this->setError('No HELO/EHLO was sent');

            return null;
        }

        if (!array_key_exists($name, $this->server_caps)) {
            if ($name == 'HELO') {
                return $this->server_caps['EHLO'];
            }
            
            if ($name == 'EHLO' || array_key_exists('EHLO', $this->server_caps)) {
                return false;
            }

            $this->setError('HELO/EHLO was not accepted');

            return null;
        }

        return $this->server_caps[$name];
    }

    /**
     * Get the last reply from the server.
     *
     * @return string
     */
    public function getLastReply()
    {
        return $this->last_reply;
    }

    /**
     * Get the current error.
     *
     * @return array
     */
    public function getError()
    {
        return $this->error;
    }

    /**
     * Get server extensions.
     *
     * @return array|null
     */
    public function getServerExtList()
    {
        return $this->server_caps;
    }

    /**
     * Connect to an SMTP server.
     *
     * @param string $host    SMTP server hostname or IP
     * @param int    $port    SMTP server port
     * @param int    $timeout Connection timeout
     * @param array  $options An array of options compatible with stream_context_create()
     *
     * @return bool
     */
    public function connect($host, $port = null, $timeout = 30, $options = [])
    {
        // Clear errors
        $this->setError('');
        
        // Store host and port
        $this->host = $host;
        $this->port = $port ?: $this->Port;
        $this->timeout = $timeout;
        
        // Connect to the SMTP server
        $errno = 0;
        $errstr = '';
        
        // Create socket context
        $context = stream_context_create($options);
        
        // Connect
        $this->smtp_conn = @stream_socket_client(
            $this->host . ':' . $this->port,
            $errno,
            $errstr,
            $timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );
        
        // Verify connection
        if (!is_resource($this->smtp_conn)) {
            $this->setError(
                'Failed to connect to server',
                $errstr,
                (string) $errno
            );
            
            if ($this->do_debug >= self::DEBUG_CONNECTION) {
                $this->edebug(
                    'SMTP ERROR: ' . $this->error['error'] . ': ' . $errstr . " (" . $errno . ")"
                );
            }
            
            return false;
        }
        
        // Set timeout
        stream_set_timeout($this->smtp_conn, $timeout);
        
        // Get server response
        $announce = $this->get_lines();
        
        if ($this->do_debug >= self::DEBUG_SERVER) {
            $this->edebug('SMTP -> FROM SERVER:' . $announce);
        }
        
        return true;
    }
}