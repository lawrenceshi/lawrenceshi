<?php
if (!defined('__TYPECHO_ADMIN__')) exit;

/**
 * 评论验证日志查看页面
 */

// 检查权限
if (!Typecho_Widget::widget('Widget_User')->pass('administrator', true)) {
    exit('Access Denied');
}

// 获取当前语言
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? "en", 0, 2);
if ($lang === 'zh') {
    $langData = include __DIR__ . '/lang/zh_CN.php';
} else {
    $langData = include __DIR__ . '/lang/en_US.php';
}

// 处理清空日志请求
if (isset($_POST['clear_logs'])) {
    $logFile = __DIR__ . "/logs.txt";
    if (file_exists($logFile)) {
        file_put_contents($logFile, '');
    }
    // 重定向以避免重复提交
    header('Location: ' . $_SERVER['REQUEST_URI']);
    exit;
}

// 日志文件路径
$logFile = __DIR__ . "/logs.txt";

// 页面标题
$title = $langData['admin_log_title'];
?>

<!DOCTYPE html>
<html lang="<?php echo $lang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title); ?> - Typecho</title>
    <link rel="stylesheet" href="<?php echo Typecho_Common::url('css/normalize.css', Typecho_Common::url('admin', Helper::options()->adminUrl)); ?>">
    <link rel="stylesheet" href="<?php echo Typecho_Common::url('css/grid.css', Typecho_Common::url('admin', Helper::options()->adminUrl)); ?>">
    <link rel="stylesheet" href="<?php echo Typecho_Common::url('css/style.css', Typecho_Common::url('admin', Helper::options()->adminUrl)); ?>">
    <style>
        /* Custom styles for log page */
        .log-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        
        .log-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .log-header h2 {
            margin: 0;
            color: #333;
            font-size: 20px;
        }
        
        .log-stats {
            display: flex;
            gap: 20px;
            font-size: 14px;
            color: #666;
        }
        
        .log-stat {
            text-align: center;
        }
        
        .log-stat .number {
            font-weight: bold;
            color: #1a73e8;
            font-size: 18px;
        }
        
        .log-content {
            padding: 20px;
            max-height: 600px;
            overflow-y: auto;
        }
        
        .log-entry {
            padding: 10px;
            margin: 5px 0;
            border-radius: 4px;
            font-family: 'Monaco', 'Consolas', monospace;
            font-size: 13px;
            line-height: 1.4;
            border-left: 3px solid #ddd;
        }
        
        .log-entry.info {
            background: #e3f2fd;
            border-left-color: #2196f3;
            color: #1565c0;
        }
        
        .log-entry.success {
            background: #e8f5e8;
            border-left-color: #4caf50;
            color: #2e7d32;
        }
        
        .log-entry.warning {
            background: #fff3e0;
            border-left-color: #ff9800;
            color: #ef6c00;
        }
        
        .log-entry.error {
            background: #ffebee;
            border-left-color: #f44336;
            color: #c62828;
        }
        
        .log-timestamp {
            color: #666;
            font-weight: bold;
            margin-right: 10px;
        }
        
        .log-message {
            color: #333;
        }
        
        .empty-log {
            text-align: center;
            padding: 40px;
            color: #999;
        }
        
        .empty-log .icon {
            font-size: 48px;
            margin-bottom: 10px;
        }
        
        .clear-button {
            background: #dc3545;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .clear-button:hover {
            background: #c82333;
        }
        
        .clear-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        
        .search-box {
            margin-bottom: 20px;
        }
        
        .search-input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        
        .filter-buttons {
            margin-bottom: 20px;
        }
        
        .filter-button {
            background: #f8f9fa;
            border: 1px solid #ddd;
            padding: 6px 12px;
            margin-right: 5px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            transition: all 0.3s;
        }
        
        .filter-button:hover {
            background: #e9ecef;
        }
        
        .filter-button.active {
            background: #1a73e8;
            color: white;
            border-color: #1a73e8;
        }
    </style>
</head>
<body>
    <div class="typecho-head-nav clearfix">
        <nav id="typecho-nav-list">
            <ul class="root">
                <li class="parent"><a href="<?php echo Typecho_Common::url('index.php', Helper::options()->adminUrl); ?>"><?php echo $langData['admin_plugin_name']; ?></a></li>
                <li class="last"><a href="<?php echo Typecho_Common::url('extending.php?panel=CommentVerify%2Flog.php', Helper::options()->adminUrl); ?>"><?php echo $langData['admin_menu_logs']; ?></a></li>
            </ul>
        </nav>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-mb-12">
                <div class="log-container">
                    <div class="log-header">
                        <h2><?php echo htmlspecialchars($title); ?></h2>
                        <div class="log-stats">
                            <div class="log-stat">
                                <div class="number" id="total-entries">0</div>
                                <div><?php echo $langData['admin_total_entries']; ?></div>
                            </div>
                            <div class="log-stat">
                                <div class="number" id="today-entries">0</div>
                                <div><?php echo $langData['admin_today_entries']; ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="log-content">
                        <?php if (file_exists($logFile) && filesize($logFile) > 0): ?>
                            <?php
                            $logs = file_get_contents($logFile);
                            $lines = array_filter(explode("\n", $logs));
                            $lines = array_reverse($lines); // 最新的在前面
                            
                            $totalEntries = count($lines);
                            $todayEntries = 0;
                            $today = date('Y-m-d');
                            
                            foreach ($lines as $line):
                                if (empty(trim($line))) continue;
                                
                                // 解析日志条目
                                if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] (.+)/', $line, $matches)) {
                                    $timestamp = $matches[1];
                                    $message = $matches[2];
                                    $logDate = substr($timestamp, 0, 10);
                                    
                                    if ($logDate === $today) {
                                        $todayEntries++;
                                    }
                                    
                                    // 确定日志类型
                                    $logType = 'info';
                                    if (strpos($message, '成功') !== false || strpos($message, 'success') !== false) {
                                        $logType = 'success';
                                    } elseif (strpos($message, '失败') !== false || strpos($message, '错误') !== false || strpos($message, 'error') !== false || strpos($message, 'failed') !== false) {
                                        $logType = 'error';
                                    } elseif (strpos($message, '警告') !== false || strpos($message, 'warning') !== false) {
                                        $logType = 'warning';
                                    }
                                    ?>
                                    <div class="log-entry <?php echo $logType; ?>">
                                        <span class="log-timestamp">[<?php echo htmlspecialchars($timestamp); ?>]</span>
                                        <span class="log-message"><?php echo htmlspecialchars($message); ?></span>
                                    </div>
                                    <?php
                                }
                            endforeach;
                            ?>
                            
                            <script>
                                document.getElementById('total-entries').textContent = '<?php echo $totalEntries; ?>';
                                document.getElementById('today-entries').textContent = '<?php echo $todayEntries; ?>';
                            </script>
                        <?php else: ?>
                            <div class="empty-log">
                                <div class="icon">📝</div>
                                <p><?php echo $langData['admin_no_logs']; ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Clear logs form -->
                <?php if (file_exists($logFile) && filesize($logFile) > 0): ?>
                <div style="text-align: center; margin: 20px 0;">
                    <form method="post" style="display: inline;">
                        <button type="submit" name="clear_logs" class="clear-button" 
                                onclick="return confirm('<?php echo $langData['admin_confirm_clear']; ?>');">
                            <?php echo $langData['admin_clear_logs']; ?>
                        </button>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>