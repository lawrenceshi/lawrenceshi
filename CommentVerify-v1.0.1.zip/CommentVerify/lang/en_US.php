<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * English Language Pack
 */
return [
    // Email related
    'email_subject' => 'Please Verify Your Comment',
    'email_title' => 'Comment Verification',
    'email_desc' => 'Thank you for your comment! Please click the link below to verify your comment (valid for 48 hours):',
    'email_info' => 'Comment Information',
    'email_nickname' => 'Nickname',
    'email_content' => 'Comment Content',
    'email_verify_button' => 'Verify Comment',
    'email_footer' => 'This email was sent automatically, please do not reply.',
    'email_expire_notice' => 'This verification link will expire in 48 hours.',
    
    // Verification results
    'verify_success' => 'Comment verified successfully!',
    'verify_failed' => 'Verification failed',
    'verify_expired' => 'Verification link expired',
    'verify_invalid' => 'Invalid verification link',
    
    // Status messages
    'redirecting' => 'Redirecting to post page...',
    'click_if_not_redirect' => 'Click here if not redirected automatically',
    'back_to_home' => 'Back to Home',
    'back_to_post' => 'Back to Post',
    
    // Error messages
    'error_no_token' => 'Missing verification parameter',
    'error_invalid_token' => 'Invalid or used verification link',
    'error_expired_token' => 'Verification link expired (over 48 hours)',
    'error_comment_not_found' => 'Comment not found',
    'error_already_approved' => 'Comment already approved',
    'error_process_failed' => 'Verification failed, please try again later',
    
    // Admin interface
    'admin_log_title' => 'Comment Verification Logs',
    'admin_no_logs' => 'No logs available',
    'admin_clear_logs' => 'Clear Logs',
    'admin_plugin_name' => 'Comment Verify',
    'admin_menu_logs' => 'Verification Logs',
    
    // Configuration interface
    'config_smtp_host' => 'SMTP Host',
    'config_smtp_port' => 'SMTP Port',
    'config_smtp_user' => 'SMTP Username',
    'config_smtp_pass' => 'SMTP Password',
    'config_from_mail' => 'From Email Address',
    'config_from_name' => 'From Display Name',
    'config_subject_prefix' => 'Email Subject Prefix',
    
    // Help texts
    'help_smtp_host' => 'e.g., smtp.gmail.com or smtp.qq.com',
    'help_smtp_port' => 'Common ports: 587 (TLS), 465 (SSL), 25 (unencrypted)',
    'help_from_mail' => 'Email address used to send verification emails',
    'help_subject_prefix' => 'Identifier prefix for email subjects',
    
    // Status information
    'status_waiting' => 'Waiting for verification',
    'status_verified' => 'Verified',
    'status_failed' => 'Verification failed',
    'status_expired' => 'Verification expired',
    
    // Time related
    'time_just_now' => 'Just now',
    'time_minutes_ago' => 'minutes ago',
    'time_hours_ago' => 'hours ago',
    'time_days_ago' => 'days ago',
    'time_weeks_ago' => 'weeks ago',
    
    // Actions
    'action_verify' => 'Verify',
    'action_resend' => 'Resend',
    'action_delete' => 'Delete',
    'action_view' => 'View',
    
    // Tips
    'tip_check_inbox' => 'Please check your email and click the verification link to complete comment verification',
    'tip_spam_folder' => 'If you don\'t receive the email, please check your spam folder',
    'tip_resend_limit' => 'You can resend the verification email up to 3 times',
    'tip_verify_required' => 'Email verification is required to display your comment',
    
    // Admin interface supplement
    'admin_total_entries' => 'Total Entries',
    'admin_today_entries' => 'Today Entries',
    'admin_confirm_clear' => 'Are you sure you want to clear all logs? This operation cannot be undone.'
];