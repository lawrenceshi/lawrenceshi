<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 中文语言包
 */
return [
    // 邮件相关
    'email_subject' => '请验证您的评论',
    'email_title' => '评论验证',
    'email_desc' => '感谢您发表评论！请点击以下链接验证您的评论（48小时内有效）：',
    'email_info' => '评论信息',
    'email_nickname' => '昵称',
    'email_content' => '评论内容',
    'email_verify_button' => '验证评论',
    'email_footer' => '此邮件由系统自动发送，请勿回复。',
    'email_expire_notice' => '此验证链接将在48小时后过期。',
    
    // 验证结果
    'verify_success' => '评论验证成功！',
    'verify_failed' => '验证失败',
    'verify_expired' => '验证链接已过期',
    'verify_invalid' => '验证链接无效',
    
    // 状态信息
    'redirecting' => '正在跳转到文章页面...',
    'click_if_not_redirect' => '如果没有自动跳转，请点击这里',
    'back_to_home' => '返回首页',
    'back_to_post' => '返回文章',
    
    // 错误信息
    'error_no_token' => '缺少验证参数',
    'error_invalid_token' => '验证链接无效或已使用',
    'error_expired_token' => '验证链接已过期（超过48小时）',
    'error_comment_not_found' => '评论不存在',
    'error_already_approved' => '评论已通过审核',
    'error_process_failed' => '验证处理失败，请稍后重试',
    
    // 管理界面
    'admin_log_title' => '评论验证日志',
    'admin_no_logs' => '暂无日志',
    'admin_clear_logs' => '清空日志',
    'admin_plugin_name' => '评论验证',
    'admin_menu_logs' => '验证日志',
    
    // 配置界面
    'config_smtp_host' => 'SMTP 主机',
    'config_smtp_port' => 'SMTP 端口',
    'config_smtp_user' => 'SMTP 用户名',
    'config_smtp_pass' => 'SMTP 密码',
    'config_from_mail' => '发件邮箱地址',
    'config_from_name' => '发件显示名称',
    'config_subject_prefix' => '邮件主题前缀',
    
    // 帮助文本
    'help_smtp_host' => '例如：smtp.gmail.com 或 smtp.qq.com',
    'help_smtp_port' => '常用端口：587（TLS）、465（SSL）、25（非加密）',
    'help_from_mail' => '发送验证邮件的邮箱地址',
    'help_subject_prefix' => '邮件主题的标识前缀',
    
    // 状态信息
    'status_waiting' => '等待验证',
    'status_verified' => '已验证',
    'status_failed' => '验证失败',
    'status_expired' => '验证过期',
    
    // 时间相关
    'time_just_now' => '刚刚',
    'time_minutes_ago' => '分钟前',
    'time_hours_ago' => '小时前',
    'time_days_ago' => '天前',
    'time_weeks_ago' => '周前',
    
    // 操作相关
    'action_verify' => '验证',
    'action_resend' => '重新发送',
    'action_delete' => '删除',
    'action_view' => '查看',
    
    // 提示信息
    'tip_check_inbox' => '请检查您的邮箱，点击验证链接完成评论验证',
    'tip_spam_folder' => '如果没有收到邮件，请检查垃圾邮件文件夹',
    'tip_resend_limit' => '最多可以重发3次验证邮件',
    'tip_verify_required' => '需要通过邮箱验证才能显示评论',
    
    // 管理界面补充
    'admin_total_entries' => '总记录数',
    'admin_today_entries' => '今日记录',
    'admin_confirm_clear' => '确定要清空所有日志吗？此操作不可恢复。'
];