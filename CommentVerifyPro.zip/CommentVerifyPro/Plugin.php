<?php
class CommentVerify_Plugin implements Typecho_Plugin_Interface
{
    const SECRET_KEY = 'CHANGE_THIS_SECRET_KEY';
    const TOKEN_EXPIRE = 48 * 3600;
    const MAX_RESEND = 3;

    public static function activate()
    {
        $db = Typecho_Db::get();
        $prefix = $db->getPrefix();

        $sql = "CREATE TABLE IF NOT EXISTS `{$prefix}comment_token` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `comment_id` INT NOT NULL,
            `token_hash` CHAR(64) NOT NULL,
            `created` INT NOT NULL,
            `resend` INT NOT NULL DEFAULT 0,
            UNIQUE(`comment_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
        $db->query($sql);

        Typecho_Plugin::factory('Widget_Feedback')->finishComment = ['CommentVerify_Plugin','prepareEmail'];
        Helper::addAction('verify-comment','CommentVerify_Action');
        Helper::addPanel(1,'CommentVerify/log.php','评论验证日志','查看验证日志','administrator');
        return "CommentVerify Pro 已启用";
    }

    public static function deactivate(){
        Helper::removePanel(1,'CommentVerify/log.php');
    }

    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('smtpHost', NULL, '', 'SMTP 主机'));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('smtpPort', NULL, '587', 'SMTP 端口'));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('smtpUser', NULL, '', 'SMTP 用户名'));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Password('smtpPass', NULL, '', 'SMTP 密码'));
        $form->addInput(new Typecho_Widget_Helper_Form_Element_Text('fromMail', NULL, '', '发件邮箱'));
    }
    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    private static function detectLang(){
        $l = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
        if(stripos($l, 'zh') !== false) return 'zh';
        return 'en';
    }

    public static function prepareEmail($comment)
    {
        $cid = $comment->coid;
        $email = $comment->mail;

        $random = bin2hex(random_bytes(32));
        $token = hash_hmac('sha256',$random,self::SECRET_KEY);

        $db = Typecho_Db::get();
        $db->query($db->insert('table.comment_token')->rows([
            'comment_id'=>$cid,
            'token_hash'=>$token,
            'created'=>time(),
            'resend'=>0
        ]));

        self::sendEmail($comment,$random);
        self::log("发送验证邮件 → $email / CID=$cid");
        return $comment;
    }

    /* PHPMailer */
    public static function sendEmail($comment,$random){
        require_once __DIR__."/phpmailer.php";
        $opt = Helper::options()->plugin('CommentVerify');

        $lang=self::detectLang();
        $template = file_get_contents(__DIR__."/mail_{$lang}.html");

        $url = Helper::options()->siteUrl."index.php/action/verify-comment?token={$random}";
        $search  = ["{{verify_url}}","{{author}}","{{email}}","{{content}}"];
        $replace = [$url,$comment->author,$comment->mail,htmlspecialchars($comment->text)];
        $html = str_replace($search,$replace,$template);

        $mail = new PHPMailer();
        $mail->isSMTP();
        $mail->Host = $opt->smtpHost;
        $mail->Port = $opt->smtpPort;
        $mail->SMTPAuth=true;
        $mail->Username=$opt->smtpUser;
        $mail->Password=$opt->smtpPass;
        $mail->From = $opt->fromMail;
        $mail->FromName="CommentVerify";
        $mail->addAddress($comment->mail);
        $mail->Subject = $lang=='zh'?"请验证您的评论":"Please Verify Your Comment";
        $mail->Body = $html;

        $mail->send();
    }

    public static function log($msg){
        file_put_contents(__DIR__."/logs.txt","[".date("Y-m-d H:i:s")."] $msg\n",FILE_APPEND);
    }
}

class CommentVerify_Action extends Typecho_Widget implements Widget_Interface_Do
{
    public function action()
    {
        $random = $this->request->token;
        $resend = $this->request->resend;
        if(!$random) die("Invalid.");

        $token = hash_hmac('sha256',$random,CommentVerify_Plugin::SECRET_KEY);
        $db = Typecho_Db::get();
        $row = $db->fetchRow($db->select()->from('table.comment_token')->where('token_hash=?',$token));
        if(!$row) die("Invalid or expired.");

        if($resend){
            if($row['resend']>=CommentVerify_Plugin::MAX_RESEND) die("Max resend reached.");
            $newRandom=bin2hex(random_bytes(32));
            $newToken=hash_hmac('sha256',$newRandom,CommentVerify_Plugin::SECRET_KEY);
            $db->query($db->update('table.comment_token')->rows([
                'token_hash'=>$newToken,
                'created'=>time(),
                'resend'=>$row['resend']+1
            ])->where('id=?',$row['id']));

            $comment=$db->fetchRow($db->select()->from('table.comments')->where('coid=?',$row['comment_id']));
            CommentVerify_Plugin::sendEmail((object)$comment,$newRandom);
            CommentVerify_Plugin::log("重发验证邮件 → {$comment['mail']}");
            die("Resent.");
        }

        if(time()-$row['created']>CommentVerify_Plugin::TOKEN_EXPIRE) die("Expired.");

        $cid=$row['comment_id'];
        $db->query($db->update('table.comments')->rows(['status'=>'approved'])->where('coid=?',$cid));
        $db->query($db->delete('table.comment_token')->where('comment_id=?',$cid));

        CommentVerify_Plugin::log("通过审核 → CID=$cid");

        // redirect to comment link
        $comment=$db->fetchRow($db->select()->from('table.comments')->where('coid=?',$cid));
        $post = $db->fetchRow($db->select()->from('table.contents')->where('cid=?',$comment['cid']));
        $url = Typecho_Common::url($post['slug']."#comment-".$cid, Helper::options()->siteUrl);

        header("Location: $url");
        exit();
    }
}
?>