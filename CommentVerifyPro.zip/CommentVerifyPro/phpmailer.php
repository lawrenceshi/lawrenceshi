<?php
// Minimal PHPMailer stub (please replace with full PHPMailer library for production)
class PHPMailer {
    public $isSMTP=false;
    public $Host;
    public $Port;
    public $SMTPAuth;
    public $Username;
    public $Password;
    public $From;
    public $FromName;
    public $Subject;
    public $Body;
    public $AltBody;
    public $CharSet="UTF-8";
    private $to=[];
    function isSMTP(){ $this->isSMTP=true; }
    function addAddress($addr){ $this->to[]=$addr; }
    function send(){
        // fallback to mail()
        $headers  = "From: {$this->From}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        foreach($this->to as $t){
            mail($t,$this->Subject,$this->Body,$headers);
        }
        return true;
    }
}
?>