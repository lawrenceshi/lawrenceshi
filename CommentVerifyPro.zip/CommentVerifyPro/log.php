<?php
if(!defined('__TYPECHO_ADMIN__')) exit;
$file = __DIR__."/logs.txt";
echo "<h2>评论验证日志</h2><pre>";
echo htmlspecialchars(file_exists($file)?file_get_contents($file):"无日志。");
echo "</pre>";
?>